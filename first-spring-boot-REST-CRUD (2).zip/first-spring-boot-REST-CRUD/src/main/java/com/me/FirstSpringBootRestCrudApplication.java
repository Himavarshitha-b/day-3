package com.me;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstSpringBootRestCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstSpringBootRestCrudApplication.class, args);
	}

}